// NOLINTNEXTLINE(misc-include-cleaner) Ignored since it's for the future
#include "cpr/parameters.h"

namespace cpr {} // namespace cpr
